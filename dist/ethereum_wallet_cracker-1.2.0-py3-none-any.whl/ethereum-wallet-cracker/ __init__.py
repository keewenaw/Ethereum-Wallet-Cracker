__author__ = "Mark Rudnitsky"
__copyright__ = "(C)2022 Mark Rudnitsky"
__credits__ = ["Mark Rudnitsky"]
__license__ = "GPLv3"
__version__ = "1.2"
__maintainer__ = "Mark Rudnitsky"
__status__ = "Production"